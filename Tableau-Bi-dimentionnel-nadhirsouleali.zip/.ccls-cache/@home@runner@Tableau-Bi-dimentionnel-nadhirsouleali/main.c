#include <stdio.h>

void print_array(int (*tab)[3], int x, int y);
void even_biarray(int (*tab)[5], int x, int y);
void odd_biarray(int (*tab)[5], int x, int y);
void diag_biarray(int (*tab)[5], int x, int y);
void eqdiag_biarray(int (*tab)[5], int x, int y);
void init_biarray(int (*tab)[5], int x, int y);
void initn_biarray(int (*tab)[5], int x, int y, int n);
int sum_biarray(int (*tab)[5], int x, int y);
void sum_row_biarray(int (*tab)[5], int x, int y);
void sum_col_biarray(int (*tab)[5], int x, int y);
int sum_diag_biarray(int (*tab)[5], int x, int y);

int main(void) {
    int tab[5][5]={{6,2,3,5,6},{4,6,2,6,1},{1,3,6,7,9},{1,6,3,6,8},{6,0,1,4,6}};
    print_array(tab, 2, 3);
    printf("\n");
    even_biarray(tab, 5, 5);
    printf("\n");
    odd_biarray(tab, 5, 5);
    printf("\n");
    diag_biarray(tab, 5, 5);
    printf("\n");
    init_biarray(tab, 5, 5);
    printf("\n");
    //initn_biarray(tab, 5, 5);
   // printf("\n");
    sum_biarray(tab, 5, 5);
    printf("\n");
    sum_row_biarray(tab, 5, 5);
    printf("\n");
    sum_col_biarray(tab, 5, 5);
    printf("\n");
    sum_diag_biarray(tab, 5, 5);
    printf("\n");


    return 0;
}

void print_array(int (*tab)[3], int x, int y){
      for (int i = 0; i < x; i++){
        for (int j = 0; j < y; j++){
            printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);
        }
    }
}
//** Exercice 1.1 **//
void even_biarray(int (*tab)[5], int x, int y){
    for (int i = 0; i < x; i++){
      for(int v = 0; v < y; v++){
        if(i % 2 == 0){
          printf("tab[%d][%d) = %d \n", i,v, tab[i][v]);
          
        }
      }
    }
}
// ** Exercice 1.2 **//
void odd_biarray(int (*tab)[5], int x, int y){
  for (int i = 0; i < x; i++){
      for(int b = 0; b < y; b++){
        if(i % 2 != 0){
          printf("tab[%d][%d) = %d \n", i,b, tab[i][b]);
          
        }
      }
    }
  }
// ** Exercice 1.3 ** //
void diag_biarray(int (*tab)[5], int x, int y){
 for (int i = 0; i < x; i++){
      for(int w = 0; w < y; w++){
        if(i == w){
          printf("tab[%d][%d] = %d \n", i,w, tab[i][w]);
          
        }
      }
    }
  }
  // ** Exercice 1.4 **//
void eqdiag_biarray(int (*tab)[5], int x, int y){
  for (int i = 0; i < x; i++){
    printf("SKIP");
    }
}
// ** Exercice 2.1 ** //
void init_biarray(int (*tab)[5], int x, int y){

  int init_biarray = 0;
  for (int i = 0; i < 0; i++){
  for (int k = 0; k < 0; k++){
    tab[i][k] = 0;

  printf("tab[%d][%d] = %d \n", i,k, tab[i][k]);
    }
   }
  }
  // ** Exercice 2.2 ** //
  // J'ai eu des doutes par rapport à  l'utilisation du tableau dans le main ou en créer un autre, à partir du 2.1 j'ai "perdu" la main... //

  void initn_biarray(int (*tab)[5], int x, int y, int n){

    int initn_biarray = 0;
    int tableau2[5] = {7,8,9,1,3};
    // Pour cette partie là, la chose qui me semblait "la plus logique" c'était de créer une variable int n sans mettre de valeur d'affectation mais même lorsque je la déclare elle était pas identifié par le compilateur //

    for (int i = 0; i < n; i++){
    for (int h = 0; h < n; h++){
      tab[i][h] = n;
      printf("tab[%d][%d] = %d \n", i, h, tab[i][h]);
   }
 }
}
// ** Exercice 3.1 ** //
int sum_biarray(int (*tab)[5], int x, int y){
  int count = 0;
  int tableau3[5] = {2,5,7,9,11};
  for (int i = 0; i < 5; i++){
    count = count + tableau3[i];
    printf("tab[%d] \n", tab[i]);
  }
  return count;
}
// ** Exercice 3.2 ** //
void sum_row_biarray(int (*tab)[5], int x, int y){
  int count = 0;
  for (int i = 0; i < 0; i++){
  for (int m = 0; m < 0; i++){
    count = count + tab[0,5];
    printf("tab[%d][%d] = %d \n", i, m, tab[i][m]);
    }
  }
}
// ** Exercice 3.3 ** //
void sum_col_biarray(int (*tab)[5], int x, int y){
  int count = 0;
  for (int i = 0; i < 0; i++){
  for (int t = 0; t < 0; i++){
    count = count + tab[1,1];
    printf("tab[%d][%d] = %d \n", i, t, tab[i][t]);
    }
  }
}
// ** Exercice 3.4 ** //
int sum_diag_biarray(int (*tab)[5], int x, int y){
  int count = 0;
  for (int i = 0; i < 0; i++){
  for (int q = 0; q < 0; i++){
    count = count + tab[0,0] && tab [1,1] && tab [2,2] && tab [3,3] && tab [4,4] && tab [5,5];

    return count;
    }
  }
}
