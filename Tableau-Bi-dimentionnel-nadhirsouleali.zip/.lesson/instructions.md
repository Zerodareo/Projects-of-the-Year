# Tableaux bidimensionnels

Un tableau bidimensionnel est une liste de tableaux unidimensionnels. Pour déclarer un tableau d’entier à deux dimensions de taille [x] [y], vous devez écrire quelque chose comme suit

```c
type nomtab[x][y];
```
 

type peut être n’importe quel type de données valide et ``nomtab` sera un identifiant valide. Un tableau bidimensionnel peut être considéré comme une table qui aura x nombre de lignes et y nombre de colonnes. Un tableau bidimensionnel tab, qui contient trois lignes et quatre colonnes, peut être représenté comme suit

  ![alt text](assets/biarray.png)

Ainsi, chaque élément du tableau tab est identifié par un nom de la forme tab [i] [j], où «tab» est le nom du tableau et «i» et «j» sont les indices qui identifient de façon unique Chaque élément dans ‘tab’.
 
## Initialisation d’un tableau bidimensionnelle
Les tableaux multidimensionnelles peuvent être initialisées en spécifiant des valeurs entre parenthèses pour chaque ligne. Voici un tableau avec 3 lignes et chaque ligne a 4 colonnes.

 ```c
int tab[2][3] = {
    {0, 3, 1},
    {7, 2, 9}
};
 ```

Les accolades imbriquées sont facultatives. L’initialisation suivante est équivalente à l’exemple précédent

 ```c
int tab[2][3] = {0, 3, 1, 7, 2, 9};
 ```

## Accès aux éléments d’un tableau à deux dimensions
Un élément d’un tableau bidimensionnel est accessible en utilisant les indices, c’est-à-dire l’indice de ligne et l’indice de colonne du tableau. Par exemple

 ```c
 int var = tab[1][2];
 ```

L’instruction ci-dessus prendra le 3ème élément de la 2ème ligne du tableau. Nous allons vérifier le programme suivant où nous avons utilisé une boucle imbriquée pour manipuler un tableau bidimensionnel

 
 ```c
    int tab[2][3] = {
        {1, 5, 1},
        {7, 3, 2}
    }

    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 3; j++){
            printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);
        }
    }
 ```

Lorsque le code ci-dessus est compilé et exécuté, il produit le résultat suivant

 

## Tableaux en paramètre de fonction 

```c
#include <stdio.h>

void print_array(int (*tab)[3], int x, int y);

int main(void) {
    int tab[2][3] = {
        {1, 5, 1},
        {7, 3, 2}
    }
    print_array(tab, 2, 3);    
    return 0;
}

void print_array(int (*tab)[3], int x, int y){
      for (int i = 0; i < x; i++){
        for (int j = 0; j < y; j++){
            printf("tab[%d][%d] = %d \n", i, j, tab[i][j]);
        }
    }
}
```
 
# EXERCICE

## Exercice 1
Soit un tableau à deux dimensions de 5 par 5 entiers complètement initialisé  par exemple:
```
6 2 3 5 6
4 6 2 6 1
1 3 6 7 9
1 6 3 6 8
6 0 1 4 6
```

```c
int tab[5][5]={{6,2,3,5,6},{4,6,2,6,1},{1,3,6,7,9},{1,6,3,6,8},{6,0,1,4,6};
```
### Exercice 1.1
Ecrire la fonction `even_biarray` affiche uniquement les ligne d'indice pair
```c
void even_biarray(int (*tab)[5], int x, int y);
```

### Exercice 1.2
Ecrire la fonction `odd_biarray` affiche uniquement les éléments d'indice impaire de chaque ligne
```c
void odd_biarray(int (*tab)[5], int x, int y);
```

### Exercice 1.3
Ecrire la fonction `diag_biarray` affiche la diagonale (de gauche à droite) 
```c
void diag_biarray(int (*tab)[5], int x, int y);
```

### Exercice 1.4
Ecrire la fonction `eqdiag_biarray` qui teste si les nombres qui apparaissent dans les deux diagonales sont tous égaux
à une seule et même valeur. Le programme affichera "OUI" ou "NON" en fonction du résultat
```c
void eqdiag_biarray(int (*tab)[5], int x, int y);
```
## Exercice 2 : initialisation
### Exercice 2.1
Ecrire la fonction `init_biarray` initalise un tableau à 0
```c
void init_biarray(int (*tab)[5], int x, int y);
```
### Exercice 2.2
Ecrire la fonction `initn_biarray` initalise un tableau à n
```c
void initn_biarray(int (*tab)[5], int x, int y, int n);
```
## Exercice 3
### Exercice 3.1
Ecrire la fonction `sum_biarray` qui retourne la somme des éléments du tableau 
```c
int sum_biarray(int (*tab)[5], int x, int y);
```
### Exercice 3.2
Ecrire la fonction `sum_row_biarray` qui affiche la somme des ligne du tableau 
```c
void sum_row_biarray(int (*tab)[5], int x, int y);
```

### Exercice 3.3
Ecrire la fonction `sum_row_biarray` qui affiche la somme des colonne du tableau 
```c
void sum_col_biarray(int (*tab)[5], int x, int y);
```

### Exercice 3.4
Ecrire la fonction `sum_diag_biarray` qui renvois la somme de la diagonal du tableau
```c
int sum_diag_biarray(int (*tab)[5], int x, int y);
```
## Exercice 4
Écrire la fonction `switch_diag_biarray` qui échange le triangle inférieur avec le triangle supérieur dans un tableau à
deux dimensions. C’est donc le tableau obtenu en faisant une symétrie par rapport à la diagonale
principale.

exemple : 
```
10 11 45 78      10 23 56 47
23 44 12 56 ---\ 11 44 90 78
56 90 67 89 ---/ 45 12 67 55
47 78 55 34      78 56 89 34
```
```c
void switch_diag_biarray(int (*tab)[5], int x, int y);
```

## Exercice 5
Ecrire la fonction `mul_n_biarray` qui multiplie le tableau tab par n
```c
void mul_n_biarray(int (*tab)[5], int x, int y);
```
## Exercice 6
Ecrire la fonction `mul_biarray` qui multiplie la matrice tab1 et tab2 et met le résultat dans tab3
```c
void mul_biarray(int (*tab1)[5], int (*tab2)[5], int (*resultat)[5], int x, int y);
```