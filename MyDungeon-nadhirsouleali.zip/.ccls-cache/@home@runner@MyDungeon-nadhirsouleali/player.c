#include "player.h"
#include <stdlib.h>
#include <stdio.h>
#include "monster.h"

void attack_player(Player *p, Monster *m){
  *m ->hp = *m->hp(p-> atk - m->def);
  return *m -> def;
}
void attack_special_player(int atk, int def, int hp){
  while(3){
    attack_player(p, m);
    if {
      *m-> hp <= 100 {
        attack_special_player = attack_special_player - m->hp;
        printf("OMAE WA MO SHINDEIRU \n");
          printf("NANI ! \n");
      }
    }
  }
attack_special_player = 500;
}