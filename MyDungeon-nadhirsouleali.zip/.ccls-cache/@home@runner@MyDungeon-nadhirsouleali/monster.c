#include "player.h"
#include <stdlib.h>
#include <stdio.h>
#include "monster.h"

void attack_monster(Player *p, Monster *m){
  *m ->hp = *m->hp (*m-> atk - *p->def);
  return *p ->def;
}