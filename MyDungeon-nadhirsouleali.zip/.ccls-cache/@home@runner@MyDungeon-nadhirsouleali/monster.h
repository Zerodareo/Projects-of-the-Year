#ifndef MONSTER_H
#define MONSTER_H
#include <stdio.h>
#include <stdlib.h>
#include "player.h"

typedef struct{
    int hp;
    int hp_max;
    int atk;
    int def;
} Monster ;

Monster *m = malloc(sizeof(Monster));
*m-> atk = 70;
*m-> def = 40;
*m-> hp  = 500;

void attack_special_monster(int atk, int hp, int def);
void attack_monster(int atk, int hp, int def);
free(Monster);

#endif