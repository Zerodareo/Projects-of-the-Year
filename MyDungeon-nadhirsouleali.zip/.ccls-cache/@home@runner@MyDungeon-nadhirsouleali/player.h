#ifndef PLAYER_H
#define PLAYER_H
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int hp;     //les points de vie
    int hp_max; //les points de vie maximum
    int atk;    // les points d'attaque
    int def;    // les points de defense 
} Player;

Player *p = malloc(sizeof(Player));
*p-> atk = 50;
*p-> def = 100;
*p-> hp  = 300;

void attack_player(int atk, int def, int hp);
void attack_special_player(int atk, int def, int hp);
void rest_player(int hp, int def);
free(Player);

#endif