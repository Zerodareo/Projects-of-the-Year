#ifndef GAME_H
#define GAME_H
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int hp;     //les points de vie
    int hp_max; //les points de vie maximum
    int atk;    // les points d'attaque
    int def;    // les points de defense 
} NPC ;

void combat(Monster *m, Player *p);
void rest(Player *p, Monster *m);
free(NPC);

#endif