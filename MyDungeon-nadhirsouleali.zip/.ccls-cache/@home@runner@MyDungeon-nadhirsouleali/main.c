#include <stdio.h>
#include "game.h"
#include "game.c"
#include "player.h"

int main(void) {
  printf("Link Start !\n");
  printf("Welcome in Aincrad \n");
  return 0;
}