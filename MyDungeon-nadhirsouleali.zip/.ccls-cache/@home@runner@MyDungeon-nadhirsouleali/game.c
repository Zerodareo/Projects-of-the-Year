#include <stdio.h>
#include <stdlib.h>
#include "game.h"
#include "player.h"
#include "monster.h"

void combat(Player *p, Monster *m){
  while(1){
    attack_player(*p, *m);
    if (*p -> atk == 50 && *m -> def == 40){
      combat = *p -> atk - *m -> def;
      return *m ->def;
      printf("Next turn : Monster, current state of the Monster :%d\n", *m ->def, *m ->hp);
    }
    while(2){
    attack_monster(*m, *p);
      if (*m -> atk == 70 && *p -> def == 100){
      combat = *m -> atk - *p -> def;
        return *p ->def;
      printf("Next turn : Player, current state of the Player : %d \n", *p ->def, *p ->hp);
      }
  }
 }
}