# MyDungeon
My dungeon est un petit projet simple, l'objectif est de faire évoluer un personnage dans un donjon. 

Ce personnage aura deux choix, combattre un ennemie, se reposer, ou afficher les statistique. 

## struct obligatoire
le personnage et les mobs doivent avoir au moins les 3 caractéristique suivante :
exemple
```c
typedef struct {
    int hp;     //les points de vie
    int hp_max; //les points de vie maximum
    int atk;    // les points d'attaque
    int def;    // les points de defense 
} Person;

```

## combat
le combat se fait dans un style hearstone
le duel est -automatique- et tour par tour, le personnage commence. 
- il attaque
    - l'adversaire prends ennemie->hp = enemie->hp - (personnage->atk - ennemie->def)
- l'ennemie attaque
- on recommence jusqu'à ce que l'un soit mort
- une fois l'ennemie mort, le joueur augmente une statistique de 1

## se reposer 
le joueur peut décider de se reposer et donc de récuperer 30% de point de vie max </br> les statistique du joueur sont aussi affiché


## structure du projet
La structure du projet est libre, vous devez penser a découper correctement votre programme. 
- faites des fichiers.c et des header.c en fonction des catégories de fonctions que vous allez coder
- la fonction main NE DOIT PAS dépasser 25 ligne

tips : 
- si vous devez faire des copier coller, ça veux dire que vous pouvez regrouper le code dans une fonction
- découpez votre projet en partie logique 