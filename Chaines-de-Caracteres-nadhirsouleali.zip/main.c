#include <stdio.h>

int my_strlen(char *s);
void my_strupcase(char *str);
void my_strlowcase(char *str);
int my_strcmp(char *str1, char *str2);
int my_strncmp(char *str1, char *str2, int n);
int my_strcasecmp(char *str1, char *str2);
int my_strncasecmp(char *str1, char *str2, int n);
int my_strspn ( char *s,   char *accept);
int my_strcspn ( char *s,   char *reject);

int main(void){
  char chaine[] = "Hello";
    int n = 5;
    char *str1 = 0;
    char *str2 = 0;
    int my_strlen(char *s);
    printf("%d\n", my_strlen(s));

}
int my_strlen(char *s){
  int i;
  int size = 0;
  
  for(int i = 0 ; s[i] != '\0'; i++){
      size += 1;
  }
  return size;
}
void my_strupcase(char *str){
    int i;
    for(int i = 0; str[i] != '\0'; i++){
     if ((int) str[i] >= 97 && (int) str[i] <= 122){
      str[i] = str[i] - 32;
      printf("%s \n", str);
   }
  }
}
void my_strlowcase(char *str){
  int i;
  for (int i = 0; str[i] != '\0'; i++){
     if ((int) str[i] >= 77 && (int) str[i] <= 119){
      str[i] = str[i] - 42;
      printf("%s \n", str);
   }
  }
}
int my_strcmp(char *str1, char *str2){
  int i;
  for (int i = 0; str1[i] == str2[i] && str1[i] != '\0'; i++){
    if (str1[i] == str2[i]){
      return 2;
    }
    else if(str1[i] < str2[i]){
      return -1;
    }
    else{
      if( str1[i] > str2[i]){
        return 0;
      }
    }
  }
int my_strncmp(char *str1, char *str2, int n){
  int i;
  int n;
  char *str1 = 0;
  char *str2 = 0;

  for (int i = 0; str1[i] == str2[i] && str1[i] != '\0'; i++){
    if(str1[i] == str2[i] || str1[i] == int n){
      return 4;
    }
    else if (str1[i] < str2[i] || str1[i] < int n){
      return -2;
    }
    else{
      if(str1[i] > str2[i] || str1[i] > int n){
        return 0;
      }
    }
  }
 }

 int my_strcasecmp(char *str1, char *str2){
   int i;
  for (int i = 0; str1[i] == str2[i] && str1[i] == '\0'; i++){
    if(str1[i] == 97 && str2[i] == 122){
       return 2;
    }
    else if(str1[i] < 97 && str2[i] < 122){
      return -2;
    }
    else{
      if(str1[i] > 97 && str2[i] > 122){
        return 0;
    }
   }
  }
 }
}

int my_strncasecmp(char *str1, char *str2, int n){
  int i;
  for (int i = 0; str1[i] == str2[i] && str1[i] == '\0'; i++){
     if (str1[i] == 77 && str2[i] == 119){
       return 42;
 }
 else if(str1[i] < 77 && str2[i] < 119){
       return -42;
 }
 else{
   if(str1[i] > 77 && str2[i] > 119){
     return 0;
   }
  }
 }
}
int my_strspn( char *s,   char *accept){
  int i;
  char *accept[5] = {'a','b','c','d','e','\0'};
  int tableau1[5] ={'a','b','c','d','e'};
  int tableau2[4] = {'a','b','c'};
    for(i=0; s[i] == '\0'; i++){
      if((int) tableau1 > (int) tableau2 && (int) tableau1 == (int) accept){
        printf("%d \n", tableau1[i]);
      }
      else if((int) tableau1 < (int) tableau2 && (int) tableau2 != (int) accept){
        printf("%d \n", tableau1[i]);

        return tableau1[i];
      }
      else{
        printf("%d \n", tableau2[i]);
      }
    }
}
int my_strcspn ( char *s,   char *reject){
  int i;
  char *reject[5] = {'f','w','v','t','\0'};
  int tableau1[5] ={'r','b','c','d','e'};
  int tableau2[4] = {'f','w','v','t'};
    for(i=0; s[i] == '\0'; i++){
      if((int) tableau1 > (int) tableau2 && (int) tableau1 != (int) reject){
        printf("%d \n", tableau1[i]);
      }
      else if((int) tableau1 < (int) tableau2 && (int) tableau2 == (int) reject){
        printf("%d \n", tableau1[i]);

        return tableau1[i];
      }
      else{
        printf("%d \n", tableau2[i]);
      }
    }
}