# Chaines de caractères
## Cours chaines : https://zestedesavoir.com/tutoriels/755/le-langage-c-1/1043_aggregats-memoire-et-fichiers/4283_les-chaines-de-caracteres/

## Table ascii :
https://upload.wikimedia.org/wikipedia/commons/d/dd/ASCII-Table.svg

## Cours Pointeur : 
https://zestedesavoir.com/tutoriels/755/le-langage-c-1/1043_aggregats-memoire-et-fichiers/4277_les-pointeurs/


## Exercice 1 : my_strlen
Ecrire la fonction `my_strlen` qui détermine la taille d'une chaine de caractère
```c
int my_strlen(char *s);
```

## Exercice 2 : my_strupcase
Ecrire la fonction `my_strupcase` qui change toutes les lettres minuscule en majuscule d'une string


```c
void my_strupcase(char *str);
```

## Exercice 3 : my_strlowcase
Ecrire la fonction `my_strlowcase` qui change toutes les lettres majuscule en minuscule d'une string


```c
void my_strlowcase(char *str);
```

## Exercice 4 : my_strcmp
Ecrire la fonction `my_strcmp` qui compare les deux chaînes s1 et s2. Elle renvoie un entier négatif, nul, ou positif, si s1 est respectivement inférieure, égale ou supérieure à s2. </br>
https://koor.fr/C/cstring/strcmp.wp

```c
int my_strcmp(char *str1, char *str2);
```

## Exercice 5 : my_strncmp
Ecrire la fonction `my_strncmp` qui compare les deux chaînes s1 et s2. Elle renvoie un entier négatif, nul, ou positif, si s1 est respectivement inférieure, égale ou supérieure à s2 jusqu'à l'index n. </br>
https://koor.fr/C/cstring/strncmp.wp


```c
int my_strncmp(char *str1, char *str2, int n);
```

## Exercice 6 : my_strcasecmp
Ecrire la fonction `my_strcasecmp` qui compare les deux chaînes s1 et s2 ignorant les différences entre majuscule et minuscule. Elle renvoie un entier négatif, nul, ou positif, si s1 est respectivement inférieure, égale ou supérieure à s2 jusqu'à l'index n. </br>
https://koor.fr/C/cstring/strcasecmp.wp


```c
int my_strcasecmp(char *str1, char *str2);
```

## Exercice 7 : my_strncasecmp
Ecrire la fonction `my_strncasecmp` qui compare les deux chaînes s1 et s2 ignorant les différences entre majuscule et minuscule. Elle renvoie un entier négatif, nul, ou positif, si s1 est respectivement inférieure, égale ou supérieure à s2 jusqu'à l'index n. </br>
https://koor.fr/C/cstring/strncasecmp.wp


```c
int my_strncasecmp(char *str1, char *str2, int n);
```

## Exercice 8 : my_strspn
Ecrire la fonction `my_strspn` qui renvoie la longueur de la plus grande sous-chaîne (en partant du début de la chaîne initiale) ne contenant que des caractères spécifiés dans la liste des caractères acceptés. </br>
https://koor.fr/C/cstring/strspn.wp


```c
int my_strspn ( char *s,   char *accept);
```

## Exercice 9 : my_strcspn
Ecrire la fonction `my_strcspn` Renvoie la longueur de la plus grande sous-chaîne (en partant du début de la chaîne initiale) ne contenant aucun des caractères spécifiés dans la liste des caractères en rejet. </br>
https://koor.fr/C/cstring/strspn.wp


```c
int my_strcspn ( char *s,   char *reject);
```

## Exercice 10 : my_strstr
Ecrire la fonction `my_strstr` recherche la première occurrence d'une sous-chaîne (paramètre substring) dans la chaîne de caractères principale (paramètre fullString).
Si la sous-chaîne est trouvée dans la chaîne principale, la fonction renvoi l’index de sa première occurenc. Dans le cas contraire, -1 vous sera renvoyé. 
 </br>
https://koor.fr/C/cstring/strstr.wp


```c
int my_strstr (char *fullstring,   char *substring);
```

## Exercice 11 : my_atoi
Ecrire la fonction `atoi` qui convertit la chaîne pointée par nptr en entier de type int. affiche une erreur et renvois -1 si la chaine ne comporte pas que des chiffres 
 </br>


```c
int my_atoi (char *str);
```